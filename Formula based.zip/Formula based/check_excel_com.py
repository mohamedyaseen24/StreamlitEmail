import winreg

try:
    winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, "Excel.Application")
    print("REGISTERED: Excel.Application exists in the registry.")
except FileNotFoundError:
    print("NOT REGISTERED: Excel.Application does not exist in the registry.")