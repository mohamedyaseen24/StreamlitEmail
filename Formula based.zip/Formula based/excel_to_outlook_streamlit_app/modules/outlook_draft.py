"""
outlook_draft.py — creates a REAL Outlook Classic draft via COM. The
summary, when present, is embedded as an inline image (Content-ID
referenced from the HTML body) AND left as a normal, visible,
downloadable attachment.
"""

from pathlib import Path

PR_ATTACH_CONTENT_ID = "http://schemas.microsoft.com/mapi/proptag/0x3712001F"


class OutlookUnavailableError(Exception):
    pass


def create_outlook_draft(subject: str, recipient: dict, body_intro_html: str,
                          attachment_path: Path, summary_image_path: Path = None):
    try:
        import win32com.client
    except ImportError as e:
        raise OutlookUnavailableError("pywin32 is not installed. Run: pip install pywin32") from e

    try:
        try:
            outlook = win32com.client.gencache.EnsureDispatch("Outlook.Application")
        except Exception:
            outlook = win32com.client.Dispatch("Outlook.Application")

        mail = outlook.CreateItem(0)
        mail.Subject = subject
        mail.To = recipient["to"]
        if recipient.get("cc"):
            mail.CC = recipient["cc"]

        cid = None
        image_html = ""
        if summary_image_path is not None:
            cid = f"summary_{Path(attachment_path).stem}"
            image_html = f'<p><img src="cid:{cid}" style="max-width:100%;"></p>'

        mail.HTMLBody = f"<html><body>{body_intro_html}{image_html}<p>Regards,</p></body></html>"

        mail.Attachments.Add(str(Path(attachment_path).resolve()))

        if summary_image_path is not None:
            img_attachment = mail.Attachments.Add(str(Path(summary_image_path).resolve()))
            img_attachment.PropertyAccessor.SetProperty(PR_ATTACH_CONTENT_ID, cid)

        mail.Save()
        return True
    except Exception as e:
        message = str(e)
        if "Invalid class string" in message or "-2147221005" in message:
            raise OutlookUnavailableError(
                "Outlook Classic isn't registered as a COM app on this machine. "
                "This usually means only 'New Outlook' is installed, or Outlook Classic hasn't been "
                "opened/signed in yet."
            ) from e
        raise OutlookUnavailableError(f"Outlook COM automation failed: {message}") from e