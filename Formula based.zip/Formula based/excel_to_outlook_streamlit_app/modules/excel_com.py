"""
excel_com.py — manages ONE shared Excel COM session for the whole batch
run. For each unit, opens the ORIGINAL file, deletes non-matching rows
using EXCEL'S OWN Delete method (not openpyxl) — Excel automatically
rewrites formula references when rows shift, which openpyxl never does
— forces a full recalculation so values are genuinely fresh for that
unit's filtered data, saves the result, then captures the summary
sheet's image from that same still-open copy before closing it.

One Excel instance runs for the entire batch, not restarted per unit.
Calculation is set to manual during each unit's edits (so a large sheet
isn't recalculated after every single row delete) and a full rebuild is
forced once, right before saving.
"""

from pathlib import Path

XL_OPEN_XML_WORKBOOK = 51
XL_CALCULATION_MANUAL = -4135
XL_UP = -4162
XL_SCREEN = 1
XL_BITMAP = 2


class ExcelUnavailableError(Exception):
    pass


def _group_consecutive(sorted_rows: list) -> list:
    if not sorted_rows:
        return []
    blocks = []
    start = prev = sorted_rows[0]
    for r in sorted_rows[1:]:
        if r == prev + 1:
            prev = r
            continue
        blocks.append((start, prev - start + 1))
        start = prev = r
    blocks.append((start, prev - start + 1))
    return blocks


class ExcelSession:
    def __init__(self):
        try:
            import win32com.client
        except ImportError as e:
            raise ExcelUnavailableError("pywin32 is not installed. Run: pip install pywin32") from e

        try:
            try:
                self.app = win32com.client.gencache.EnsureDispatch("Excel.Application")
            except Exception:
                self.app = win32com.client.Dispatch("Excel.Application")

            self.app.Visible = False
            self.app.DisplayAlerts = False
            self.app.ScreenUpdating = False
            self.app.Calculation = XL_CALCULATION_MANUAL

            # Scratch canvas reused for every unit's summary image export.
            self._scratch_wb = self.app.Workbooks.Add()
            scratch_ws = self._scratch_wb.Worksheets(1)
            self._chart_obj = scratch_ws.ChartObjects().Add(Left=0, Top=0, Width=400, Height=300)
        except Exception as e:
            message = str(e)
            if "Invalid class string" in message or "-2147221005" in message:
                raise ExcelUnavailableError(
                    "Excel isn't registered as a COM app on this machine. Desktop Excel must be "
                    "installed and have been opened at least once."
                ) from e
            raise ExcelUnavailableError(f"Could not start Excel: {message}") from e

    def _find_unit_column(self, ws, aliases):
        alias_set = {a.strip().lower() for a in aliases}
        used = ws.UsedRange
        last_col = used.Column + used.Columns.Count - 1
        for c in range(1, last_col + 1):
            value = ws.Cells(1, c).Value
            if value is not None and str(value).strip().lower() in alias_set:
                return c
        return None

    def process_unit(self, original_path: Path, unit_value: str, unit_column_aliases: list,
                      summary_pattern: str, output_path: Path, image_output_path: Path) -> dict:
        """Does the whole per-unit job in one open/close cycle: split
        (with correct formula handling), recalculate, save, then
        capture the summary sheet's image from that same saved copy.
        Returns {"rows_kept": {...}, "summary_image_path": Path or None}."""
        import re

        target = str(unit_value).strip()
        rows_kept = {}

        try:
            wb = self.app.Workbooks.Open(str(Path(original_path).resolve()))
        except Exception as e:
            raise ExcelUnavailableError(f"Could not open '{Path(original_path).name}': {e}") from e

        try:
            for ws in wb.Worksheets:
                col = self._find_unit_column(ws, unit_column_aliases)
                if col is None:
                    continue  # no unit column on this sheet -> leave fully intact

                last_row = ws.Cells(ws.Rows.Count, col).End(XL_UP).Row
                if last_row < 2:
                    rows_kept[ws.Name] = 0
                    continue

                rows_to_delete = []
                kept = 0
                for row_idx in range(2, last_row + 1):
                    value = ws.Cells(row_idx, col).Value
                    if value is not None and str(value).strip() == target:
                        kept += 1
                    else:
                        rows_to_delete.append(row_idx)
                rows_kept[ws.Name] = kept

                # Delete in batched, contiguous blocks, largest-row-first,
                # using Excel's own Delete so formula references update correctly.
                for start, count in reversed(_group_consecutive(rows_to_delete)):
                    ws.Range(f"{start}:{start + count - 1}").EntireRow.Delete()

            # One full, explicit recalculation before saving — guarantees
            # every formula's value reflects this unit's filtered data,
            # not a stale cached number from the original file.
            self.app.CalculateFullRebuild()

            wb.SaveAs(str(Path(output_path).resolve()), FileFormat=XL_OPEN_XML_WORKBOOK)

            # Capture the summary image from this SAME now-split, now-saved
            # copy — no need to reopen the file a second time.
            summary_image_path = None
            for ws in wb.Worksheets:
                if re.search(summary_pattern, ws.Name, re.IGNORECASE):
                    used_range = ws.UsedRange
                    if used_range.Rows.Count > 1:  # more than just a header
                        self._chart_obj.Width = used_range.Width
                        self._chart_obj.Height = used_range.Height
                        used_range.CopyPicture(Appearance=XL_SCREEN, Format=XL_BITMAP)
                        self._chart_obj.Chart.ChartArea.Select()
                        self._chart_obj.Chart.Paste()
                        self._chart_obj.Chart.Export(str(Path(image_output_path).resolve()), FilterName="PNG")
                        summary_image_path = image_output_path
                    break

            return {"rows_kept": rows_kept, "summary_image_path": summary_image_path}

        except Exception as e:
            raise ExcelUnavailableError(f"Could not process '{unit_value}': {e}") from e
        finally:
            wb.Close(SaveChanges=False)

    def shutdown(self):
        try:
            self._scratch_wb.Close(SaveChanges=False)
        except Exception:
            pass
        try:
            self.app.Quit()
        except Exception:
            pass