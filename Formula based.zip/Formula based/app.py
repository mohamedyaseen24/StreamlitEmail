"""
app.py — Streamlit front-end for the Excel-to-Outlook pipeline.

Accepts .xlsx/.xlsm (native) and .xls/.xlsb (legacy, via pandas) with
no conversion step for either.

Native files are split via Excel COM automation (not openpyxl) so that
formula references get correctly rewritten and recalculated when rows
are deleted — openpyxl never adjusts formula text on row deletion, so
this is the only reliable way to keep formulas correct per unit. The
same Excel session that splits a unit's file also captures its summary
sheet as an image in the same pass, so the file is only opened once.

Legacy files (.xls/.xlsb) go through the values-only pandas path: no
formulas, no styles, no summary image — that trade-off was accepted
earlier as the cost of reading those formats with zero conversion step.
"""

import shutil

import pandas as pd
import streamlit as st

from modules import config
from modules.excel_loader import save_uploaded_file
from modules.unit_finder import build_sheet_index, build_sheet_index_pandas, collect_all_units
from modules.splitter import build_unit_workbook_excel, build_unit_workbook_pandas
from modules.recipients import load_recipient_mapping, resolve_recipient
from modules.outlook_draft import create_outlook_draft, OutlookUnavailableError
from modules.excel_com import ExcelSession, ExcelUnavailableError

st.set_page_config(page_title="Excel → Outlook Draft Generator", layout="wide")

st.markdown(
    f"""
    <style>
    .stButton>button {{
        background-color: {config.ACCENT_COLOR};
        color: #0E1117;
        font-weight: 600;
        border-radius: 8px;
        border: none;
        padding: 0.6em 1.4em;
    }}
    .stButton>button:hover {{
        background-color: {config.ACCENT_COLOR_DARK};
        color: white;
    }}
    div[data-testid="stMetric"] {{
        background-color: {config.CARD_BG};
        border-radius: 10px;
        padding: 12px;
    }}
    </style>
    """,
    unsafe_allow_html=True,
)

st.title("📊 Excel → Outlook Draft Generator")
st.caption("Upload a workbook (.xlsx, .xlsm, .xls, .xlsb), click Start — everything else happens automatically.")

uploaded_file = st.file_uploader("Master Excel workbook", type=["xlsx", "xlsm", "xls", "xlsb"])

start_disabled = uploaded_file is None
if st.button("🚀 Start Process", type="primary", disabled=start_disabled):

    status = st.empty()
    results = []
    excel_session = None

    try:
        # --- 0. Fresh output folder every run ---
        if config.OUTPUT_DIR.exists():
            shutil.rmtree(config.OUTPUT_DIR)
        config.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

        # --- 1. Save upload, detect format ---
        status.info("💾 Saving uploaded file...")
        saved_path = save_uploaded_file(uploaded_file, config.UPLOAD_DIR)
        ext = saved_path.suffix.lower()

        # --- 2. Build the unit index — different reader per format, same output shape ---
        status.info("🔍 Scanning sheets for unit data...")
        if ext in config.NATIVE_EXTENSIONS:
            from modules.excel_loader import open_workbook
            wb = open_workbook(saved_path)
            sheet_index = build_sheet_index(wb, config.UNIT_COLUMN_ALIASES)
        elif ext in config.LEGACY_EXTENSIONS:
            sheet_index = build_sheet_index_pandas(saved_path, config.UNIT_COLUMN_ALIASES)
        else:
            st.error(f"Unsupported file type: {ext}")
            st.stop()

        units = collect_all_units(sheet_index)

        if not units:
            st.error(
                f"No unit column found matching any of {config.UNIT_COLUMN_ALIASES} on any sheet. "
                "Check modules/config.py's UNIT_COLUMN_ALIASES if your file uses a different header."
            )
            st.stop()

        status.success(f"✅ {len(units)} unit(s) detected: {', '.join(units)}")
        if ext in config.LEGACY_EXTENSIONS:
            st.info(
                f"ℹ️ {ext} is read without any conversion step — split files for these units use plain "
                "formatting (no formulas/styles to carry over, no summary image)."
            )

        # --- 3. Recipients (required — no dummy fallback) ---
        try:
            mapping = load_recipient_mapping(config.RECIPIENT_MAPPING_PATH)
        except (FileNotFoundError, ValueError) as e:
            st.error(f"❌ {e}")
            st.stop()

        # --- 4. Start ONE shared Excel COM session for the whole run
        #        (only needed for native files, but cheap to start either way) ---
        if ext in config.NATIVE_EXTENSIONS:
            try:
                excel_session = ExcelSession()
            except ExcelUnavailableError as e:
                st.error(f"❌ Could not start Excel: {e}")
                st.stop()

        # --- 5. Per unit: split (+ summary image for native files), then draft ---
        progress = st.progress(0.0, text="Processing units...")

        for i, unit_value in enumerate(units):
            row = {"Unit": unit_value, "Rows kept": "-", "Recipient": "-", "Status": "-"}

            status.info(f"⚙️ Splitting {unit_value}...")
            if ext in config.NATIVE_EXTENSIONS:
                split_result = build_unit_workbook_excel(
                    excel_session, saved_path, unit_value, config.UNIT_COLUMN_ALIASES,
                    config.SUMMARY_SHEET_PATTERN, config.OUTPUT_DIR
                )
                summary_png = split_result["summary_image_path"]
            else:
                split_result = build_unit_workbook_pandas(sheet_index, unit_value, config.OUTPUT_DIR)
                summary_png = None

            row["Rows kept"] = sum(split_result["rows_kept"].values())

            recipient = resolve_recipient(unit_value, mapping)
            if recipient is None:
                row["Status"] = "⚠️ Skipped — no recipient mapping found"
                results.append(row)
                progress.progress((i + 1) / len(units), text=f"Processed {unit_value}")
                continue

            row["Recipient"] = recipient["to"]

            body_intro = f"<p>Hi,</p><p>Please find attached the finance document for <b>{unit_value}</b>.</p>"
            subject = config.SUBJECT_TEMPLATE.format(unit=unit_value)

            status.info(f"📧 Creating Outlook draft for {unit_value}...")
            try:
                create_outlook_draft(subject, recipient, body_intro, split_result["path"], summary_png)
                row["Status"] = "✅ Draft created"
            except OutlookUnavailableError as e:
                row["Status"] = f"❌ Failed — {e}"

            results.append(row)
            progress.progress((i + 1) / len(units), text=f"Processed {unit_value}")

        progress.empty()
        status.empty()

    finally:
        if excel_session is not None:
            excel_session.shutdown()

    # --- 6. Final summary ---
    if results:
        results_df = pd.DataFrame(results)
        st.subheader("Results")
        st.dataframe(results_df, use_container_width=True, hide_index=True)

        created = sum(1 for r in results if r["Status"] == "✅ Draft created")
        skipped = sum(1 for r in results if "Skipped" in r["Status"])
        failed = sum(1 for r in results if "Failed" in r["Status"])

        col1, col2, col3 = st.columns(3)
        col1.metric("Drafts created", created)
        col2.metric("Skipped (no mapping)", skipped)
        col3.metric("Failed", failed)

        if created:
            st.success(f"🎉 {created} of {len(results)} draft(s) created in Outlook. Review and send from your Drafts folder.")
        if skipped:
            st.warning(f"{skipped} unit(s) skipped — add them to {config.RECIPIENT_MAPPING_PATH.name} and re-run.")
        if failed:
            st.error(f"{failed} unit(s) failed — see the reason in the Results table above.")