"""
outlook_draft.py — one job: create a REAL Outlook Classic draft (with a
working Send button, saved into your Drafts folder) via COM automation.

There is no .eml fallback in this version, per requirements — if Outlook
Classic COM automation isn't available, this raises/returns an error
that the caller reports for that unit, rather than silently writing a
file instead.

Requires: Windows + desktop Outlook Classic installed and signed in +
pywin32 installed.
"""

from pathlib import Path


class OutlookUnavailableError(Exception):
    pass


def create_outlook_draft(subject: str, recipient: dict, html_body: str, attachment_path: Path):
    """Creates and SAVES (never sends) a real Outlook draft item.
    Raises OutlookUnavailableError with a clear, actionable message on
    any failure — caller should catch this per-unit and keep going."""
    try:
        import win32com.client
    except ImportError as e:
        raise OutlookUnavailableError(
            "pywin32 is not installed. Run: pip install pywin32"
        ) from e

    try:
        try:
            outlook = win32com.client.gencache.EnsureDispatch("Outlook.Application")
        except Exception:
            outlook = win32com.client.Dispatch("Outlook.Application")

        mail = outlook.CreateItem(0)  # 0 = olMailItem
        mail.Subject = subject
        mail.To = recipient["to"]
        if recipient.get("cc"):
            mail.CC = recipient["cc"]
        mail.HTMLBody = html_body
        mail.Attachments.Add(str(Path(attachment_path).resolve()))
        mail.Save()  # saves into the Drafts folder — does NOT send
        return True
    except Exception as e:
        message = str(e)
        if "Invalid class string" in message or "-2147221005" in message:
            raise OutlookUnavailableError(
                "Outlook Classic isn't registered as a COM app on this machine. "
                "This usually means only 'New Outlook' is installed (which doesn't support "
                "this automation), or Outlook Classic hasn't been opened/signed in yet."
            ) from e
        raise OutlookUnavailableError(f"Outlook COM automation failed: {message}") from e
