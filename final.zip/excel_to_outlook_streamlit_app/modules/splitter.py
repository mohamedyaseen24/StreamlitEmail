"""
splitter.py — copies the original workbook per unit, deleting
non-matching rows in batched, contiguous groups instead of one at a
time (each individual delete_rows() call re-indexes everything below
it, so batching is the key fix for large files).

Also handles .xls/.xlsb sources via pandas (values only, no conversion
step) — same output shape either way.
"""

import re
from pathlib import Path

import pandas as pd
from openpyxl import load_workbook


def safe_filename(value: str) -> str:
    text = str(value).strip()
    text = re.sub(r'[\\/*?:"<>|]', "_", text)
    text = re.sub(r"\s+", "_", text)
    return text or "blank"


def _group_consecutive(sorted_rows: list) -> list:
    if not sorted_rows:
        return []
    blocks = []
    start = prev = sorted_rows[0]
    for r in sorted_rows[1:]:
        if r == prev + 1:
            prev = r
            continue
        blocks.append((start, prev - start + 1))
        start = prev = r
    blocks.append((start, prev - start + 1))
    return blocks


def build_unit_workbook(original_path: Path, unit_value: str, sheet_index: dict, output_dir: Path) -> dict:
    """For .xlsx/.xlsm (native, via openpyxl)."""
    wb = load_workbook(original_path, data_only=False)
    rows_kept = {}
    target = str(unit_value).strip()

    for ws in wb.worksheets:
        info = sheet_index.get(ws.title)
        if info is None:
            continue

        last_row = info["last_row"]
        row_units = info["row_units"]

        rows_to_delete = [r for r in range(2, last_row + 1) if row_units.get(r) != target]
        if ws.max_row > last_row:
            rows_to_delete.extend(range(last_row + 1, ws.max_row + 1))

        rows_kept[ws.title] = sum(1 for u in row_units.values() if u == target)

        for start, count in reversed(_group_consecutive(sorted(rows_to_delete))):
            ws.delete_rows(start, count)

    out_path = output_dir / f"{safe_filename(unit_value)}.xlsx"
    wb.save(out_path)
    return {"path": out_path, "rows_kept": rows_kept}


def build_unit_workbook_pandas(sheet_index_pandas: dict, unit_value: str, output_dir: Path) -> dict:
    """For .xls/.xlsb: rebuilds a NEW .xlsx per unit from extracted
    values. Plain default formatting — nothing to carry over."""
    out_path = output_dir / f"{safe_filename(unit_value)}.xlsx"
    rows_kept = {}
    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        for sheet_name, info in sheet_index_pandas.items():
            df = info["dataframe"]
            col = info["unit_col"]
            filtered = df[df[col].astype(str).str.strip() == str(unit_value).strip()]
            filtered.to_excel(writer, sheet_name=sheet_name[:31], index=False)
            rows_kept[sheet_name] = len(filtered)
    return {"path": out_path, "rows_kept": rows_kept}