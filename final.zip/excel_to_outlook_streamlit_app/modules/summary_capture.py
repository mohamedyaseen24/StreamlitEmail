"""
summary_capture.py — one job: turn a worksheet into an HTML table whose
inline styles match the original Excel formatting as closely as
practical: fill color, font (bold/italic/color/size), borders, text
alignment, merged cells, and common number formats (currency, percent,
thousands separator, dates).

What this deliberately does NOT attempt (documented in README.md):
conditional formatting (color scales/data bars/icon sets — Excel
computes these dynamically, openpyxl only exposes the rule, not the
resulting color), exotic custom number formats, non-standard fonts,
embedded charts/images, or exact column-width/row-height layout.
"""

import re
from datetime import datetime

from openpyxl.utils import get_column_letter


def find_summary_sheet(wb, pattern: str):
    """Returns the first worksheet whose name matches the summary
    pattern (case-insensitive), or None if there isn't one."""
    for ws in wb.worksheets:
        if re.search(pattern, ws.title, re.IGNORECASE):
            return ws
    return None


def sheet_has_data(ws) -> bool:
    """True if the sheet has at least one non-empty row below the header."""
    for row in ws.iter_rows(min_row=2):
        if any(cell.value is not None for cell in row):
            return True
    return False


def _argb_to_css(argb):
    if not argb or len(argb) < 6:
        return None
    rgb = argb[-6:]  # drop alpha if present (ARGB -> RGB)
    if rgb.upper() == "000000" and len(argb) == 8 and argb.upper().startswith("00"):
        return None  # fully transparent
    return f"#{rgb}"


def _fill_css(cell):
    fill = cell.fill
    if fill is None or fill.patternType != "solid":
        return ""
    color = _argb_to_css(fill.fgColor.rgb if fill.fgColor and fill.fgColor.type == "rgb" else None)
    return f"background-color:{color};" if color else ""


def _font_css(cell):
    font = cell.font
    if font is None:
        return ""
    parts = []
    if font.bold:
        parts.append("font-weight:bold;")
    if font.italic:
        parts.append("font-style:italic;")
    if font.size:
        parts.append(f"font-size:{int(font.size)}px;")
    color = _argb_to_css(font.color.rgb if font.color and font.color.type == "rgb" else None)
    if color:
        parts.append(f"color:{color};")
    return "".join(parts)


def _border_css(cell):
    border = cell.border
    if border is None:
        return ""
    parts = []
    for side_name, css_side in (("top", "top"), ("bottom", "bottom"), ("left", "left"), ("right", "right")):
        side = getattr(border, side_name)
        if side and side.style:
            color = _argb_to_css(side.color.rgb if side.color and side.color.type == "rgb" else None) or "#999999"
            parts.append(f"border-{css_side}:1px solid {color};")
    return "".join(parts)


def _alignment_css(cell):
    align = cell.alignment
    if align is None or not align.horizontal:
        return ""
    return f"text-align:{align.horizontal};"


_EXCEL_DATE_TOKENS = [
    ("yyyy", "%Y"), ("yy", "%y"),
    ("mmmm", "%B"), ("mmm", "%b"), ("mm", "%m"),
    ("dddd", "%A"), ("ddd", "%a"), ("dd", "%d"),
]


def _format_value(cell):
    value = cell.value
    if value is None:
        return ""
    fmt = cell.number_format or ""

    if isinstance(value, datetime):
        py_fmt = fmt
        for token, replacement in _EXCEL_DATE_TOKENS:
            py_fmt = py_fmt.replace(token, replacement)
        try:
            return value.strftime(py_fmt)
        except ValueError:
            return value.strftime("%Y-%m-%d")

    if isinstance(value, (int, float)):
        if "%" in fmt:
            decimals = fmt.count("0", fmt.find(".") + 1) if "." in fmt else 0
            return f"{value * 100:,.{decimals}f}%"

        currency_symbol = next((s for s in ("$", "\u20b9", "\u20ac", "\u00a3") if s in fmt), None)
        if currency_symbol or "#,##0" in fmt:
            decimals = fmt.count("0", fmt.find(".") + 1) if "." in fmt else 0
            formatted = f"{value:,.{decimals}f}"
            return f"{currency_symbol}{formatted}" if currency_symbol else formatted

        if isinstance(value, float) and value.is_integer():
            return str(int(value))
        return str(value)

    return str(value)


def sheet_to_html_table(ws) -> str:
    """Renders the sheet's used range as an HTML table with inline
    styles approximating the original formatting, including merged
    cells (colspan/rowspan)."""
    merged_anchor = {}   # (row, col) -> (rowspan, colspan)
    merged_skip = set()  # (row, col) cells covered by a merge but not the anchor

    for merged_range in ws.merged_cells.ranges:
        min_row, min_col, max_row, max_col = (
            merged_range.min_row, merged_range.min_col, merged_range.max_row, merged_range.max_col
        )
        merged_anchor[(min_row, min_col)] = (max_row - min_row + 1, max_col - min_col + 1)
        for r in range(min_row, max_row + 1):
            for c in range(min_col, max_col + 1):
                if (r, c) != (min_row, min_col):
                    merged_skip.add((r, c))

    rows_html = []
    for row in ws.iter_rows(min_row=1, max_row=ws.max_row, min_col=1, max_col=ws.max_column):
        cells_html = []
        for cell in row:
            pos = (cell.row, cell.column)
            if pos in merged_skip:
                continue

            style = "padding:6px 10px;" + _fill_css(cell) + _font_css(cell) + _border_css(cell) + _alignment_css(cell)
            tag = "th" if cell.row == 1 else "td"
            span_attrs = ""
            if pos in merged_anchor:
                rowspan, colspan = merged_anchor[pos]
                if rowspan > 1:
                    span_attrs += f' rowspan="{rowspan}"'
                if colspan > 1:
                    span_attrs += f' colspan="{colspan}"'

            cells_html.append(f'<{tag} style="{style}"{span_attrs}>{_format_value(cell)}</{tag}>')
        rows_html.append(f"<tr>{''.join(cells_html)}</tr>")

    return (
        '<table style="border-collapse:collapse; font-family:Calibri,Arial,sans-serif; '
        f'font-size:13px; margin:8px 0 20px 0;">{"".join(rows_html)}</table>'
    )
