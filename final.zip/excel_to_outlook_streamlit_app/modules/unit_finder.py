"""
unit_finder.py — scans every sheet exactly ONCE, regardless of how many
units exist, building a per-sheet row->unit index plus the real last
row of actual data (ignoring any inflated/phantom used-range that large
real files often report). splitter.py uses this index directly instead
of rescanning cell values once per unit.

Also handles .xls/.xlsb sources via pandas (values only, no conversion
step) — collect_all_units() works unchanged on either source, since
both produce the same {"row_units": {...}} shape.
"""

import pandas as pd


def find_unit_column(ws, aliases):
    alias_set = {a.strip().lower() for a in aliases}
    for cell in ws[1]:
        if cell.value is not None and str(cell.value).strip().lower() in alias_set:
            return cell.column
    return None


def _real_last_data_row(ws, min_row=2):
    for row_idx in range(ws.max_row, min_row - 1, -1):
        if any(cell.value is not None for cell in ws[row_idx]):
            return row_idx
    return min_row - 1


def build_sheet_index(wb, aliases):
    """For .xlsx/.xlsm (native, via openpyxl)."""
    index = {}
    for ws in wb.worksheets:
        col = find_unit_column(ws, aliases)
        if col is None:
            continue
        last_row = _real_last_data_row(ws)
        row_units = {}
        for row_idx in range(2, last_row + 1):
            value = ws.cell(row=row_idx, column=col).value
            if value is not None and str(value).strip():
                row_units[row_idx] = str(value).strip()
        index[ws.title] = {"col": col, "last_row": last_row, "row_units": row_units}
    return index


def build_sheet_index_pandas(path, aliases):
    """For .xls/.xlsb (via pandas — values only, no conversion step)."""
    sheets = pd.read_excel(path, sheet_name=None, header=0)
    alias_set = {a.strip().lower() for a in aliases}
    index = {}
    for name, df in sheets.items():
        unit_col = next((c for c in df.columns if str(c).strip().lower() in alias_set), None)
        if unit_col is None:
            continue
        row_units = {}
        for i, value in enumerate(df[unit_col], start=2):
            if pd.notna(value) and str(value).strip():
                row_units[i] = str(value).strip()
        index[name] = {"row_units": row_units, "dataframe": df, "unit_col": unit_col}
    return index


def collect_all_units(sheet_index: dict):
    units = set()
    for sheet_info in sheet_index.values():
        units.update(sheet_info["row_units"].values())
    return sorted(units, key=str)