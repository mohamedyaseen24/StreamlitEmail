"""
config.py — shared constants. Edit these directly when something needs
to change (e.g. a new unit-column header variant shows up).
"""

from pathlib import Path

APP_DIR = Path(__file__).resolve().parent.parent

# Column headers (checked case-insensitively) that identify the unit
# column on any given sheet. Add more strings here if a new file uses a
# different header — no other code needs to change.
UNIT_COLUMN_ALIASES = ["unit name", "unit"]

# File extensions read natively by openpyxl — full fidelity (formulas,
# styles, merged cells all preserved through the split).
NATIVE_EXTENSIONS = {".xlsx", ".xlsm"}

# File extensions read via pandas (xlrd/pyxlsb engines) — values only,
# no conversion step, but also no formulas/styles to carry through, so
# split output for these is a freshly built .xlsx with plain formatting.
LEGACY_EXTENSIONS = {".xls", ".xlsb"}

# Sheet names (regex, case-insensitive) treated as the summary sheet.
SUMMARY_SHEET_PATTERN = r"summary|sum"

SUBJECT_TEMPLATE = "Finance document of the {unit}"

# Fixed locations, all relative to the app folder.
RECIPIENT_MAPPING_PATH = APP_DIR / "recipients.xlsx"
UPLOAD_DIR = APP_DIR / "uploads"
OUTPUT_DIR = APP_DIR / "split_output"

# Theme accents used in app.py's custom CSS.
ACCENT_COLOR = "#00C2A8"
ACCENT_COLOR_DARK = "#00A896"
CARD_BG = "#1E2530""""
config.py — shared constants. Edit these directly when something needs
to change (e.g. a new unit-column header variant shows up).
"""

from pathlib import Path

APP_DIR = Path(__file__).resolve().parent.parent

# Column headers (checked case-insensitively) that identify the unit
# column on any given sheet. Add more strings here if a new file uses a
# different header — no other code needs to change.
UNIT_COLUMN_ALIASES = ["unit name", "unit"]

# File extensions read natively by openpyxl — full fidelity (formulas,
# styles, merged cells all preserved through the split).
NATIVE_EXTENSIONS = {".xlsx", ".xlsm"}

# File extensions read via pandas (xlrd/pyxlsb engines) — values only,
# no conversion step, but also no formulas/styles to carry through, so
# split output for these is a freshly built .xlsx with plain formatting.
LEGACY_EXTENSIONS = {".xls", ".xlsb"}

# Sheet names (regex, case-insensitive) treated as the summary sheet.
SUMMARY_SHEET_PATTERN = r"summary|sum"

SUBJECT_TEMPLATE = "Finance document of the {unit}"

# Fixed locations, all relative to the app folder.
RECIPIENT_MAPPING_PATH = APP_DIR / "recipients.xlsx"
UPLOAD_DIR = APP_DIR / "uploads"
OUTPUT_DIR = APP_DIR / "split_output"

# Theme accents used in app.py's custom CSS.
ACCENT_COLOR = "#00C2A8"
ACCENT_COLOR_DARK = "#00A896"
CARD_BG = "#1E2530"