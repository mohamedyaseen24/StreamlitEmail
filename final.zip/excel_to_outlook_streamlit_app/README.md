# Excel → Outlook Draft Generator (Streamlit)

Upload a multi-sheet workbook, click **Start**, and get:
- One `.xlsx` per unit, each a full copy of the original file with only
  that unit's rows kept — every sheet, every formula, every color and
  border untouched.
- A real, editable Outlook Classic draft per unit, with the summary
  sheet rendered as a styled HTML table and the unit's file attached.

---

## 1. One-time setup

1. Install Python 3.10+ ([python.org](https://www.python.org/downloads/)). On Windows, check "Add python.exe to PATH".
2. Install VS Code with the Python extension.
3. Unzip this project, open the folder in VS Code (**File → Open Folder**).
4. Open a terminal and run:
   ```
   pip install -r requirements.txt
   ```
5. **Edit `recipients.xlsx`** (already in this folder, pre-filled with sample data) with your real Unit / To / CC mapping. Columns: `Unit Name` (or `Unit`), `To`, `CC` — header matching is case-insensitive. Multiple addresses in one cell: separate with `;`.

## 2. Run it

```
streamlit run app.py
```

This opens the app in your browser. Upload your workbook, click **🚀 Start Process**. That's it — no other input needed.

## 3. What happens when you click Start

1. `split_output/` is wiped and rebuilt fresh (previous run's files don't linger).
2. Every sheet is scanned for a unit column (see **Changing the unit-column name** below) and the full, deduplicated unit list is built.
3. For each unit: a full copy of the original file is made, then every row not belonging to that unit is deleted from every sheet that has a unit column. Sheets without a unit column are left completely untouched. Saved as `split_output/<Unit>.xlsx`.
4. `recipients.xlsx` is loaded. **Any unit not found in it is skipped** — no placeholder/dummy address is ever used. The Results table flags exactly which units were skipped.
5. For every matched unit: if a Summary-named sheet has rows for that unit, it's rendered as a styled HTML table (see below) and placed in the draft body along with the attached file. A real Outlook Classic draft is created — subject `Finance document of the <Unit>`, saved to your Drafts folder, never sent automatically.
6. A results table and a final count (created / skipped / failed) are shown. If one unit fails, the rest keep processing — check the Status column for the specific reason.

## Changing the unit-column name

Open `modules/config.py`:

```python
UNIT_COLUMN_ALIASES = ["unit name", "unit"]
```

Add any other header variant your files use — matching is case-insensitive and checked against every sheet independently.

## What the HTML summary table can and can't reproduce

**Reproduces accurately:** fill color, font (bold/italic/color/size), borders, text alignment, merged cells, and common number formats (currency, percentages, thousands separators, dates).

**Won't reproduce:**
- Conditional formatting (color scales, data bars, icon sets) — Excel computes these at render time; the underlying rule is visible to code, not the resulting color.
- Very unusual custom number formats.
- Non-standard fonts (falls back to the recipient's default font).
- Embedded charts, images, or sparklines inside the summary sheet.
- Exact column widths/row heights (Outlook renders HTML via Word's engine, not Excel's).

## Project layout

```
excel_to_outlook_streamlit_app/
├── app.py                    # Streamlit UI — the whole flow
├── requirements.txt
├── README.md
├── recipients.xlsx           # YOUR mapping file — edit with real addresses
├── .streamlit/config.toml    # dark theme
└── modules/
    ├── config.py              # aliases, subject template, fixed paths, theme colors
    ├── excel_loader.py        # persist upload, open workbook
    ├── unit_finder.py         # detect unit column, collect full unit list
    ├── splitter.py             # copy-and-delete-rows split (preserves original formatting)
    ├── recipients.py           # load mapping, resolve per unit (no dummy fallback)
    ├── summary_capture.py      # worksheet -> styled HTML table
    └── outlook_draft.py        # real Outlook Classic draft via COM automation
```

## Troubleshooting

| Problem | Fix |
|---|---|
| `'streamlit' is not recognized` / import errors | Re-run `pip install -r requirements.txt` |
| "No unit column found..." | Add your file's actual header text to `UNIT_COLUMN_ALIASES` in `modules/config.py` |
| Every unit shows "Skipped — no recipient mapping found" | Check `recipients.xlsx` — unit names must match exactly (case-insensitive) what's in your workbook |
| Status shows "Outlook Classic isn't registered as a COM app..." | This machine only has **New Outlook**, which doesn't support this kind of automation — classic desktop Outlook must be installed and signed in. No code change can work around this; see the note below |
| `pywin32 is not installed` | On Windows: `pip install pywin32` |

### About New Outlook vs. Outlook Classic

Real, editable Outlook drafts (the kind with a working Send button) are
only possible via Outlook Classic's COM interface. **New Outlook does
not expose this at all** — this is a Microsoft platform limitation, not
something any code here can fix. If a unit's status shows the "isn't
registered as a COM app" error, that machine needs Outlook Classic
installed and signed in, not just New Outlook.
