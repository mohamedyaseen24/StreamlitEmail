# Excel → Outlook Draft Generator (v2)

Upload a multi-sheet workbook — `.xlsx`, `.xlsm`, `.xlsb`, or `.xls` —
click **Start**, and get:
- One `.xlsx` per unit, each a full copy of the original file with only
  that unit's rows kept — every sheet, every formula, every color and
  border untouched.
- A real, editable Outlook Classic draft per unit, with the unit's
  summary sheet embedded as an image (pixel-accurate to the original
  formatting) plus the unit's file attached.

---

## What changed from v1, and why

| Problem seen with real data | Fix |
|---|---|
| Processing looked stuck on a large file | Row scanning now happens **once per sheet total**, not once per unit — and the code detects the *real* last row of data itself instead of trusting a possibly-inflated file property |
| Still slow even after that | Row deletion is now **batched** — consecutive rows-to-delete are grouped into single operations instead of one at a time |
| Only `.xlsx` accepted | `.xlsb` and `.xls` are now converted to `.xlsx` automatically via Excel itself before anything else runs |
| Summary lost its colors/formatting in the email | Summary is now captured as an **image** straight from Excel's own rendering, not rebuilt from styling rules that can miss things (theme colors, conditional formatting, etc.) |
| No visibility during long steps | Live status messages throughout — converting, scanning, splitting, capturing, drafting — so slow-but-working is never confused with stuck |

## Honest performance notes (measured, not assumed)

The row-deletion batching fix's benefit depends on how a unit's rows
are arranged in the sheet:

- **Rows naturally grouped by unit** (common in exported reports): very
  fast — roughly 0.1s per unit per 5,000 rows in testing.
- **Rows fully interleaved** (every row a different unit, worst case):
  meaningfully slower — roughly 1.2s per unit per 5,000 rows in testing,
  since a non-contiguous pattern still means many separate delete
  operations even after batching.

Either way, the critical fix holds: processing time now scales with
your **actual** data size, not with a phantom/inflated used-range that
could previously make even a small real file behave like it had
hundreds of thousands of rows. A large, heavily-interleaved file will
take longer than a grouped one, but it will finish, and the live status
messages mean you'll see it progressing rather than wondering if it's
frozen.

---

## How it works, step by step

1. **Save + convert** (`excel_loader.py`, `format_converter.py`, `excel_com.py`) — the upload is saved to disk; if it's `.xlsb`/`.xls`, Excel itself converts it to `.xlsx` first (calculation is forced to manual and alerts disabled during this, so a large file with many formulas can't silently trigger a blocking recalculation or dialog).
2. **Index once** (`unit_finder.py`) — every sheet is scanned exactly once, building a row→unit map and the real last-data-row, and from that, the full deduplicated unit list.
3. **Split per unit** (`splitter.py`) — a fresh copy of the original file per unit, non-matching rows deleted in batched groups using the index from step 2 (no rescanning).
4. **Resolve recipients** (`recipients.py`) — loads `recipients.xlsx` from this folder. **No dummy fallback** — a unit with no matching row is skipped and flagged, never sent to a placeholder address.
5. **Capture the summary image** (`summary_image.py`, `excel_com.py`) — the unit's already-split summary sheet is opened via the same shared Excel session, its used range copied and exported as a PNG. Pixel-accurate because it's Excel doing the rendering, not replicated styling rules.
6. **Create the draft** (`outlook_draft.py`) — a real, editable Outlook Classic draft: subject `Finance document of the <Unit>`, the summary image embedded inline in the body *and* left as a normal, downloadable attachment, plus the unit's `.xlsx` file attached. Only `.Save()` is ever called — nothing is sent automatically.
7. **You review, then send manually** from your Outlook Drafts folder.

One shared Excel COM session runs for the entire batch (not restarted per unit), and is explicitly closed at the end — so no invisible `EXCEL.EXE` process is left running even if something fails partway through.

---

## 1. One-time setup

1. Install Python 3.10+ ([python.org](https://www.python.org/downloads/)). On Windows, check "Add python.exe to PATH".
2. Install VS Code with the Python extension.
3. Unzip this project, open the folder in VS Code (**File → Open Folder**).
4. Open a terminal and run:
   ```
   pip install -r requirements.txt
   ```
5. **Edit `recipients.xlsx`** (pre-filled with sample data) with your real Unit / To / CC mapping. Columns: `Unit Name` (or `Unit`), `To`, `CC` — case-insensitive. Multiple addresses in one cell: separate with `;`.

## 2. Run it

```
streamlit run app.py
```

Upload your workbook, click **🚀 Start Process**.

## Changing the unit-column name

Edit `modules/config.py`:
```python
UNIT_COLUMN_ALIASES = ["unit name", "unit"]
```
Add any other header variant your files use.

## What the summary image can and can't do

**Always accurate**, because it's Excel's own rendering: fill colors (including theme colors and tints — the most common real-world gap in a hand-built HTML approach), fonts, borders, merged cells, conditional formatting, number formats, everything.

**Trade-off accepted for that accuracy**: it's a picture, not text — the recipient can't select/copy the numbers directly out of the email body. The full data is always still available in the attached `.xlsx` and in the image as a separate downloadable attachment.

## Project layout

```
excel_to_outlook_v2/
├── app.py
├── requirements.txt
├── README.md
├── recipients.xlsx           # YOUR mapping file — edit with real addresses
├── .streamlit/config.toml    # dark theme
└── modules/
    ├── config.py              # aliases, subject template, fixed paths, theme colors
    ├── excel_loader.py        # persist upload to disk
    ├── format_converter.py    # decides if .xlsb/.xls need converting
    ├── excel_com.py           # shared Excel COM session: conversion + image export
    ├── unit_finder.py         # single-pass indexing across all sheets
    ├── splitter.py             # batched-deletion split, preserves original formatting
    ├── recipients.py           # load mapping, resolve per unit (no dummy fallback)
    ├── summary_image.py        # unit's summary sheet -> PNG via the shared Excel session
    └── outlook_draft.py        # real Outlook Classic draft via COM (inline + attached image)
```

## Troubleshooting

| Problem | Fix |
|---|---|
| `'streamlit' is not recognized` / import errors | Re-run `pip install -r requirements.txt` |
| "No unit column found..." | Add your file's actual header text to `UNIT_COLUMN_ALIASES` in `modules/config.py` |
| Every unit shows "Skipped — no recipient mapping found" | Check `recipients.xlsx` — unit names must match exactly (case-insensitive) |
| "Could not start Excel..." / "isn't registered as a COM app" | Desktop Excel must be installed and have been opened at least once on this machine |
| "Outlook Classic isn't registered as a COM app..." | This machine only has **New Outlook**, which doesn't support this automation at all — see note below |
| `pywin32 is not installed` | On Windows: `pip install pywin32` |
| A very large file takes a long time on one step | Expected for a heavily-interleaved large sheet (see performance notes above) — check the live status message; it should still be progressing, not frozen |

### About New Outlook vs. Outlook Classic

Real, editable Outlook drafts are only possible via Outlook Classic's
COM interface — **New Outlook does not expose this at all**, and no
code change can work around that. If you see the "isn't registered as
a COM app" error, that machine needs Outlook Classic installed and
signed in, not just New Outlook.
