"""
splitter.py — one job: for a given unit, produce a copy of the ORIGINAL
workbook with every row that doesn't belong to that unit deleted,
preserving everything else (formulas, formatting, merged cells) exactly.

Two performance fixes vs. the first version:
  1. Uses the row->unit index built ONCE in unit_finder.py, instead of
     re-scanning every cell's value for every unit.
  2. Deletes rows in batched, contiguous groups (openpyxl.delete_rows(
     start, count)) instead of one row at a time — each individual
     delete_rows() call has to re-index every row below it, so calling
     it once per row on a large sheet is far more expensive than
     calling it once per contiguous block of rows.

Reloading the original file fresh per unit is still necessary (each
unit needs its own independent copy to destructively edit), but that
cost no longer compounds with a full rescan on top of it.
"""

import re
from pathlib import Path

from openpyxl import load_workbook


def safe_filename(value: str) -> str:
    text = str(value).strip()
    text = re.sub(r'[\\/*?:"<>|]', "_", text)
    text = re.sub(r"\s+", "_", text)
    return text or "blank"


def _group_consecutive(sorted_rows: list) -> list:
    """[5, 6, 7, 10, 11] -> [(5, 3), (10, 2)] — (start_row, count) blocks
    of consecutive row numbers, so each block needs only one delete_rows() call."""
    if not sorted_rows:
        return []
    blocks = []
    start = prev = sorted_rows[0]
    for r in sorted_rows[1:]:
        if r == prev + 1:
            prev = r
            continue
        blocks.append((start, prev - start + 1))
        start = prev = r
    blocks.append((start, prev - start + 1))
    return blocks


def build_unit_workbook(original_path: Path, unit_value: str, sheet_index: dict, output_dir: Path) -> dict:
    """Loads a fresh copy of the original file, deletes every row not
    belonging to unit_value on every sheet present in sheet_index
    (sheets without a unit column are left completely untouched), and
    saves it as <unit>.xlsx. Returns {"path": Path, "rows_kept": {sheet: int}}."""
    wb = load_workbook(original_path, data_only=False)
    rows_kept = {}
    target = str(unit_value).strip()

    for ws in wb.worksheets:
        info = sheet_index.get(ws.title)
        if info is None:
            continue  # no unit column on this sheet -> leave fully intact

        last_row = info["last_row"]
        row_units = info["row_units"]

        rows_to_delete = [r for r in range(2, last_row + 1) if row_units.get(r) != target]
        # Also drop anything beyond the real last data row, in case the
        # sheet's reported max_row was inflated by a phantom range —
        # keeps the split file's size sane too, not just the run time.
        if ws.max_row > last_row:
            rows_to_delete.extend(range(last_row + 1, ws.max_row + 1))

        rows_kept[ws.title] = sum(1 for u in row_units.values() if u == target)

        # Delete largest-row-first so each block's row numbers are still
        # valid at the moment it's deleted.
        for start, count in reversed(_group_consecutive(sorted(rows_to_delete))):
            ws.delete_rows(start, count)

    out_path = output_dir / f"{safe_filename(unit_value)}.xlsx"
    wb.save(out_path)
    return {"path": out_path, "rows_kept": rows_kept}
