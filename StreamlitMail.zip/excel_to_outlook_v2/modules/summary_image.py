"""
summary_image.py — replaces the earlier styled-HTML-table approach.
One job: given a unit's already-split workbook, find its summary sheet
and export that sheet's used range as a PNG via the shared Excel COM
session — an exact visual match to the original file, since Excel
itself renders it, with no cell-styling-replication logic to keep
extending as new formatting (theme colors, conditional formatting,
etc.) turns up in real files.
"""

import re
from pathlib import Path

from openpyxl import load_workbook


def find_summary_sheet_name(path: Path, pattern: str):
    """Cheap check via openpyxl (no Excel COM needed just to read sheet
    names) — returns the first sheet name matching the summary pattern,
    or None."""
    wb = load_workbook(path, read_only=True)
    try:
        for name in wb.sheetnames:
            if re.search(pattern, name, re.IGNORECASE):
                return name
    finally:
        wb.close()
    return None


def export_summary_image(excel_session, unit_xlsx_path: Path, summary_pattern: str, output_dir: Path):
    """Returns the PNG path if an image was created, or None if this
    unit has no summary sheet, or that sheet has no data rows."""
    sheet_name = find_summary_sheet_name(unit_xlsx_path, summary_pattern)
    if sheet_name is None:
        return None

    output_dir.mkdir(parents=True, exist_ok=True)
    png_path = output_dir / f"{Path(unit_xlsx_path).stem}_summary.png"
    created = excel_session.export_range_as_png(unit_xlsx_path, sheet_name, png_path)
    return png_path if created else None
