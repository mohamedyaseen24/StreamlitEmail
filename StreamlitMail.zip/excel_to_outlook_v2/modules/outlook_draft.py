"""
outlook_draft.py — one job: create a REAL Outlook Classic draft (with a
working Send button, saved into your Drafts folder) via COM automation.

The summary, when present, is embedded as an inline image in the body
(referenced by Content-ID) AND left as a normal, visible attachment —
so it shows inline for a quick read, and is also separately downloadable,
alongside the unit's Excel file.

No .eml fallback in this version — if Outlook Classic COM automation
isn't available, this raises a clear error for the caller to report
against that specific unit, rather than silently writing a file instead.
"""

from pathlib import Path

# MAPI property tag used to set an attachment's Content-ID, so it can be
# referenced from the HTML body via <img src="cid:...">.
PR_ATTACH_CONTENT_ID = "http://schemas.microsoft.com/mapi/proptag/0x3712001F"


class OutlookUnavailableError(Exception):
    pass


def create_outlook_draft(subject: str, recipient: dict, body_intro_html: str,
                          attachment_path: Path, summary_image_path: Path = None):
    """Creates and SAVES (never sends) a real Outlook draft item.
    Raises OutlookUnavailableError with a clear, actionable message on
    any failure — caller should catch this per-unit and keep going."""
    try:
        import win32com.client
    except ImportError as e:
        raise OutlookUnavailableError("pywin32 is not installed. Run: pip install pywin32") from e

    try:
        try:
            outlook = win32com.client.gencache.EnsureDispatch("Outlook.Application")
        except Exception:
            outlook = win32com.client.Dispatch("Outlook.Application")

        mail = outlook.CreateItem(0)  # 0 = olMailItem
        mail.Subject = subject
        mail.To = recipient["to"]
        if recipient.get("cc"):
            mail.CC = recipient["cc"]

        cid = None
        image_html = ""
        if summary_image_path is not None:
            cid = f"summary_{Path(attachment_path).stem}"
            image_html = f'<p><img src="cid:{cid}" style="max-width:100%;"></p>'

        mail.HTMLBody = f"<html><body>{body_intro_html}{image_html}<p>Regards,</p></body></html>"

        # The unit's split Excel file — always attached.
        mail.Attachments.Add(str(Path(attachment_path).resolve()))

        # The summary image — attached normally (so it stays visible
        # and downloadable in the attachment list) and additionally
        # tagged with a Content-ID so the <img> tag above can find it.
        if summary_image_path is not None:
            img_attachment = mail.Attachments.Add(str(Path(summary_image_path).resolve()))
            img_attachment.PropertyAccessor.SetProperty(PR_ATTACH_CONTENT_ID, cid)

        mail.Save()  # saves into the Drafts folder — does NOT send
        return True
    except Exception as e:
        message = str(e)
        if "Invalid class string" in message or "-2147221005" in message:
            raise OutlookUnavailableError(
                "Outlook Classic isn't registered as a COM app on this machine. "
                "This usually means only 'New Outlook' is installed (which doesn't support this "
                "automation), or Outlook Classic hasn't been opened/signed in yet."
            ) from e
        raise OutlookUnavailableError(f"Outlook COM automation failed: {message}") from e
