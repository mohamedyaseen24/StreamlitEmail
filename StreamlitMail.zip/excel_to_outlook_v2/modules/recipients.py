"""
recipients.py — one job: load the fixed-path recipient mapping file and
resolve To/CC per unit. There is NO dummy fallback — a unit with no
matching row is reported as skipped, not sent to a placeholder address.
"""

from pathlib import Path

import pandas as pd


def load_recipient_mapping(path: Path) -> dict:
    """Reads an .xlsx (or .csv) with columns Unit/Unit Name, To, CC
    (case-insensitive). Returns {unit_lower: {"to":..., "cc":...}}."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"Recipient mapping file not found at {path}. "
            "Create it with columns: Unit Name (or Unit), To, CC."
        )

    if path.suffix.lower() in (".xlsx", ".xls"):
        df = pd.read_excel(path, dtype=str).fillna("")
    else:
        df = pd.read_csv(path, dtype=str).fillna("")

    cols = {str(c).strip().lower(): c for c in df.columns}
    unit_col = cols.get("unit name") or cols.get("unit")
    to_col = cols.get("to")
    cc_col = cols.get("cc")

    if not unit_col or not to_col:
        raise ValueError(
            f"'{path.name}' must have a 'Unit Name' (or 'Unit') column and a 'To' column. "
            f"Found: {list(df.columns)}"
        )

    mapping = {}
    for _, row in df.iterrows():
        unit = str(row[unit_col]).strip()
        if not unit:
            continue
        mapping[unit.lower()] = {
            "to": str(row[to_col]).strip(),
            "cc": str(row[cc_col]).strip() if cc_col else "",
        }
    return mapping


def resolve_recipient(unit_value: str, mapping: dict):
    """Returns the recipient dict for this unit, or None if there's no
    match — callers should skip the unit entirely when this is None,
    never substitute a placeholder address."""
    entry = mapping.get(str(unit_value).strip().lower())
    if entry and entry.get("to"):
        return entry
    return None
