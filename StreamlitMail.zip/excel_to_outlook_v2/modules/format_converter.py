"""
format_converter.py — one job: decide whether an uploaded file needs
converting before openpyxl can touch it, and hand that off to the
shared Excel COM session.

openpyxl only reads modern, XML-based .xlsx/.xlsm files. The legacy
binary .xls format and the compressed binary .xlsb format are
structurally different files entirely — no pure-Python library reads
either while preserving formulas and formatting. Excel itself, via COM,
is the only free, full-fidelity way to get from either into .xlsx.
"""

from pathlib import Path

NEEDS_CONVERSION_EXTENSIONS = {".xlsb", ".xls"}


def needs_conversion(path: Path) -> bool:
    return Path(path).suffix.lower() in NEEDS_CONVERSION_EXTENSIONS


def convert_if_needed(excel_session, path: Path, output_dir: Path) -> Path:
    """Returns a path openpyxl can open safely. If the file is already
    .xlsx/.xlsm, returns it unchanged. Otherwise converts it via the
    shared Excel session and returns the new .xlsx path."""
    path = Path(path)
    if not needs_conversion(path):
        return path

    output_dir.mkdir(parents=True, exist_ok=True)
    converted_path = output_dir / (path.stem + ".xlsx")
    excel_session.convert_to_xlsx(path, converted_path)
    return converted_path
