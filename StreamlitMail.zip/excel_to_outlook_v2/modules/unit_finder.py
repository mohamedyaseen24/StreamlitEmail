"""
unit_finder.py — one job: scan every sheet exactly ONCE, regardless of
how many units exist, and build:
  - a per-sheet index of which row belongs to which unit, plus the real
    last row of actual data (ignoring any inflated/phantom used-range
    that large real-world files often report)
  - from that index, the complete deduplicated list of units

splitter.py uses this index directly instead of rescanning cell values
once per unit — the single biggest fix for the "stuck on large files"
problem, since scanning used to happen len(units) times over.
"""


def find_unit_column(ws, aliases):
    """Scans row 1 for a header matching one of the aliases. Returns the
    1-based column index, or None if this sheet has no unit column."""
    alias_set = {a.strip().lower() for a in aliases}
    for cell in ws[1]:
        if cell.value is not None and str(cell.value).strip().lower() in alias_set:
            return cell.column
    return None


def _real_last_data_row(ws, min_row=2):
    """Scans backward from the sheet's reported max_row to find the
    last row that actually has any non-empty cell. Protects against a
    phantom/inflated used-range (very common in real workbooks — old
    formatting or a formula ever dragged far past the last real row
    makes Excel remember a huge used range forever) turning a simple
    split into hundreds of thousands of wasted row checks."""
    for row_idx in range(ws.max_row, min_row - 1, -1):
        if any(cell.value is not None for cell in ws[row_idx]):
            return row_idx
    return min_row - 1  # sheet has no data rows at all


def build_sheet_index(wb, aliases):
    """One pass per sheet, done once for the whole run. Returns:
        {sheet_name: {"col": int, "last_row": int, "row_units": {row_idx: unit_str}}}
    Only sheets that actually have a matching unit column are included;
    sheets without one are left out entirely (splitter.py leaves those
    sheets fully untouched)."""
    index = {}
    for ws in wb.worksheets:
        col = find_unit_column(ws, aliases)
        if col is None:
            continue

        last_row = _real_last_data_row(ws)
        row_units = {}
        for row_idx in range(2, last_row + 1):
            value = ws.cell(row=row_idx, column=col).value
            if value is not None and str(value).strip():
                row_units[row_idx] = str(value).strip()

        index[ws.title] = {"col": col, "last_row": last_row, "row_units": row_units}
    return index


def collect_all_units(sheet_index: dict):
    """The full, deduplicated, sorted list of units found anywhere,
    read straight from the index built above — no re-scanning."""
    units = set()
    for sheet_info in sheet_index.values():
        units.update(sheet_info["row_units"].values())
    return sorted(units, key=str)
