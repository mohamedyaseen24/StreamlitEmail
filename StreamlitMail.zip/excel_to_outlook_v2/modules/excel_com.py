"""
excel_com.py — manages ONE shared Excel COM session for the entire
batch run, used for two things:
  1. Converting a legacy/binary file (.xlsb, .xls) to .xlsx before
     openpyxl touches it — openpyxl can only read modern .xlsx/.xlsm.
  2. Exporting a worksheet's used range as a PNG image — pixel-exact to
     the original file's real formatting, since Excel itself renders
     it (no cell-styling-replication code to maintain or get wrong).

Opening Excel once for the whole run (not once per unit) avoids
repeating Excel's own startup cost per unit. Calculation is forced to
manual and alerts/screen-updating are disabled for the session's
lifetime — on a large file with many formulas, letting Excel try to
fully recalculate on open, or pop a blocking "keep this format?" dialog
that never gets clicked, are both realistic causes of an automation
run looking silently stuck.
"""

from pathlib import Path

XL_OPEN_XML_WORKBOOK = 51        # .xlsx file format constant
XL_CALCULATION_MANUAL = -4135
XL_SCREEN = 1
XL_BITMAP = 2


class ExcelUnavailableError(Exception):
    pass


class ExcelSession:
    def __init__(self):
        try:
            import win32com.client
        except ImportError as e:
            raise ExcelUnavailableError("pywin32 is not installed. Run: pip install pywin32") from e

        try:
            try:
                self.app = win32com.client.gencache.EnsureDispatch("Excel.Application")
            except Exception:
                self.app = win32com.client.Dispatch("Excel.Application")

            self.app.Visible = False
            self.app.DisplayAlerts = False
            self.app.ScreenUpdating = False
            self.app.Calculation = XL_CALCULATION_MANUAL

            # A scratch workbook used purely as a canvas for image
            # export. Never saved — it exists only so we have somewhere
            # to paste a copied range and export it as a picture.
            self._scratch_wb = self.app.Workbooks.Add()
            scratch_ws = self._scratch_wb.Worksheets(1)
            self._chart_obj = scratch_ws.ChartObjects().Add(Left=0, Top=0, Width=400, Height=300)
        except Exception as e:
            message = str(e)
            if "Invalid class string" in message or "-2147221005" in message:
                raise ExcelUnavailableError(
                    "Excel isn't registered as a COM app on this machine. Desktop Excel must be "
                    "installed and have been opened at least once."
                ) from e
            raise ExcelUnavailableError(f"Could not start Excel: {message}") from e

    def convert_to_xlsx(self, source_path: Path, dest_path: Path) -> Path:
        """Opens source_path (.xlsb, .xls, or anything Excel can read)
        and saves a copy as dest_path in modern .xlsx format. The
        source file itself is never modified."""
        try:
            wb = self.app.Workbooks.Open(str(Path(source_path).resolve()))
            try:
                wb.SaveAs(str(Path(dest_path).resolve()), FileFormat=XL_OPEN_XML_WORKBOOK)
            finally:
                wb.Close(SaveChanges=False)
            return dest_path
        except Exception as e:
            raise ExcelUnavailableError(f"Could not convert '{Path(source_path).name}': {e}") from e

    def export_range_as_png(self, workbook_path: Path, sheet_name: str, output_png_path: Path) -> bool:
        """Opens workbook_path read-only, copies sheet_name's used
        range as a picture, pastes it onto the shared scratch chart
        (resized to match), and exports that as a PNG. Returns True if
        an image was produced, False if the sheet has no data rows
        beyond its header. The source file is never modified or saved."""
        try:
            wb = self.app.Workbooks.Open(str(Path(workbook_path).resolve()), ReadOnly=True)
        except Exception as e:
            raise ExcelUnavailableError(f"Could not open '{Path(workbook_path).name}' for image export: {e}") from e

        try:
            ws = wb.Worksheets(sheet_name)
            used_range = ws.UsedRange
            if used_range.Rows.Count <= 1:  # header row only, or empty
                return False

            self._chart_obj.Width = used_range.Width
            self._chart_obj.Height = used_range.Height

            used_range.CopyPicture(Appearance=XL_SCREEN, Format=XL_BITMAP)
            self._chart_obj.Chart.ChartArea.Select()
            self._chart_obj.Chart.Paste()
            self._chart_obj.Chart.Export(str(Path(output_png_path).resolve()), FilterName="PNG")
            return True
        except Exception as e:
            raise ExcelUnavailableError(f"Could not export summary image: {e}") from e
        finally:
            wb.Close(SaveChanges=False)

    def shutdown(self):
        """Always call this once at the end of a run — leaves no
        invisible EXCEL.EXE process running in the background."""
        try:
            self._scratch_wb.Close(SaveChanges=False)
        except Exception:
            pass
        try:
            self.app.Quit()
        except Exception:
            pass
