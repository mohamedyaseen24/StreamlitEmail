"""
excel_loader.py — one job: get the uploaded workbook onto disk as a real
file (Outlook/Excel COM automation both need a real path, not just the
in-memory upload Streamlit hands you), and open it for reading.
"""

from pathlib import Path

from openpyxl import load_workbook


def save_uploaded_file(uploaded_file, upload_dir: Path) -> Path:
    """Writes the Streamlit-uploaded file to disk, overwriting any
    previous upload of the same name. Returns the saved path."""
    upload_dir.mkdir(parents=True, exist_ok=True)
    dest = upload_dir / uploaded_file.name
    dest.write_bytes(uploaded_file.getvalue())
    return dest


def open_workbook(path: Path):
    """Opens the workbook keeping formulas/formatting intact (data_only=False),
    so anything saved from it later is still a fully functional Excel file."""
    return load_workbook(path, data_only=False)
