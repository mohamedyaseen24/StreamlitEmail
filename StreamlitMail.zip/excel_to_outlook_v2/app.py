"""
app.py — Streamlit front-end for the Excel-to-Outlook pipeline (v2).

Changes from v1:
  - Accepts .xlsx, .xlsm, .xlsb, .xls (non-native formats are converted
    via Excel COM before anything else touches them).
  - Unit detection and row splitting are single-pass + batched, so a
    large real file no longer looks stuck.
  - The summary is embedded as a PNG image (inline + downloadable),
    not an HTML table — exact visual match, nothing to keep extending
    as new Excel formatting features turn up.
  - Live status messages throughout, so a genuinely slow step (Excel
    conversion, a huge sheet) is visibly progressing, not indistinguishable
    from actually being stuck.
"""

import shutil
from pathlib import Path

import pandas as pd
import streamlit as st
from openpyxl import load_workbook

from modules import config
from modules.excel_loader import save_uploaded_file
from modules.format_converter import needs_conversion, convert_if_needed
from modules.unit_finder import build_sheet_index, collect_all_units
from modules.splitter import build_unit_workbook
from modules.recipients import load_recipient_mapping, resolve_recipient
from modules.summary_image import export_summary_image
from modules.outlook_draft import create_outlook_draft, OutlookUnavailableError
from modules.excel_com import ExcelSession, ExcelUnavailableError

st.set_page_config(page_title="Excel → Outlook Draft Generator", layout="wide")

st.markdown(
    f"""
    <style>
    .stButton>button {{
        background-color: {config.ACCENT_COLOR};
        color: #0E1117;
        font-weight: 600;
        border-radius: 8px;
        border: none;
        padding: 0.6em 1.4em;
    }}
    .stButton>button:hover {{
        background-color: {config.ACCENT_COLOR_DARK};
        color: white;
    }}
    div[data-testid="stMetric"] {{
        background-color: {config.CARD_BG};
        border-radius: 10px;
        padding: 12px;
    }}
    </style>
    """,
    unsafe_allow_html=True,
)

st.title("📊 Excel → Outlook Draft Generator")
st.caption("Upload a workbook (.xlsx, .xlsm, .xlsb, .xls), click Start — everything else happens automatically.")

uploaded_file = st.file_uploader("Master Excel workbook", type=["xlsx", "xlsm", "xlsb", "xls"])

start_disabled = uploaded_file is None
if st.button("🚀 Start Process", type="primary", disabled=start_disabled):

    status = st.empty()
    results = []
    excel_session = None

    try:
        # --- 0. Fresh output folder every run ---
        if config.OUTPUT_DIR.exists():
            shutil.rmtree(config.OUTPUT_DIR)
        config.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

        # --- 1. Save upload ---
        status.info("💾 Saving uploaded file...")
        saved_path = save_uploaded_file(uploaded_file, config.UPLOAD_DIR)

        # --- 2. One shared Excel COM session for the whole run ---
        try:
            excel_session = ExcelSession()
        except ExcelUnavailableError as e:
            st.error(f"❌ Could not start Excel: {e}")
            st.stop()

        # --- 3. Convert to .xlsx first, if this isn't already a native format ---
        working_path = saved_path
        if needs_conversion(saved_path):
            status.info(f"🔄 Converting {saved_path.suffix} to .xlsx via Excel — this can take a while on a large file...")
            try:
                working_path = convert_if_needed(excel_session, saved_path, config.UPLOAD_DIR)
            except ExcelUnavailableError as e:
                st.error(f"❌ Conversion failed: {e}")
                st.stop()

        # --- 4. Single-pass scan: index every sheet once, then read the unit list from it ---
        status.info("🔍 Scanning sheets for unit data...")
        wb = load_workbook(working_path, data_only=False)
        sheet_index = build_sheet_index(wb, config.UNIT_COLUMN_ALIASES)
        units = collect_all_units(sheet_index)

        if not units:
            st.error(
                f"No unit column found matching any of {config.UNIT_COLUMN_ALIASES} on any sheet. "
                "Check modules/config.py's UNIT_COLUMN_ALIASES if your file uses a different header."
            )
            st.stop()

        status.success(f"✅ {len(units)} unit(s) detected: {', '.join(units)}")

        # --- 5. Recipients (required — no dummy fallback) ---
        try:
            mapping = load_recipient_mapping(config.RECIPIENT_MAPPING_PATH)
        except (FileNotFoundError, ValueError) as e:
            st.error(f"❌ {e}")
            st.stop()

        # --- 6. Per unit: split, capture summary image, create the draft ---
        progress = st.progress(0.0, text="Processing units...")

        for i, unit_value in enumerate(units):
            row = {"Unit": unit_value, "Rows kept": "-", "Recipient": "-", "Summary image": "-", "Status": "-"}

            status.info(f"⚙️ Splitting {unit_value}...")
            split_result = build_unit_workbook(working_path, unit_value, sheet_index, config.OUTPUT_DIR)
            row["Rows kept"] = sum(split_result["rows_kept"].values())

            recipient = resolve_recipient(unit_value, mapping)
            if recipient is None:
                row["Status"] = "⚠️ Skipped — no recipient mapping found"
                results.append(row)
                progress.progress((i + 1) / len(units), text=f"Processed {unit_value}")
                continue

            row["Recipient"] = recipient["to"]

            status.info(f"🖼️ Capturing summary image for {unit_value}...")
            try:
                summary_png = export_summary_image(
                    excel_session, split_result["path"], config.SUMMARY_SHEET_PATTERN, config.OUTPUT_DIR
                )
                row["Summary image"] = "Yes" if summary_png else "No summary for this unit"
            except ExcelUnavailableError as e:
                summary_png = None
                row["Summary image"] = f"Failed — {e}"

            body_intro = f"<p>Hi,</p><p>Please find attached the finance document for <b>{unit_value}</b>.</p>"
            subject = config.SUBJECT_TEMPLATE.format(unit=unit_value)

            status.info(f"📧 Creating Outlook draft for {unit_value}...")
            try:
                create_outlook_draft(subject, recipient, body_intro, split_result["path"], summary_png)
                row["Status"] = "✅ Draft created"
            except OutlookUnavailableError as e:
                row["Status"] = f"❌ Failed — {e}"

            results.append(row)
            progress.progress((i + 1) / len(units), text=f"Processed {unit_value}")

        progress.empty()
        status.empty()

    finally:
        if excel_session is not None:
            excel_session.shutdown()

    # --- 7. Final summary ---
    if results:
        results_df = pd.DataFrame(results)
        st.subheader("Results")
        st.dataframe(results_df, use_container_width=True, hide_index=True)

        created = sum(1 for r in results if r["Status"] == "✅ Draft created")
        skipped = sum(1 for r in results if "Skipped" in r["Status"])
        failed = sum(1 for r in results if "Failed" in r["Status"])

        col1, col2, col3 = st.columns(3)
        col1.metric("Drafts created", created)
        col2.metric("Skipped (no mapping)", skipped)
        col3.metric("Failed", failed)

        if created:
            st.success(f"🎉 {created} of {len(results)} draft(s) created in Outlook. Review and send from your Drafts folder.")
        if skipped:
            st.warning(f"{skipped} unit(s) skipped — add them to {config.RECIPIENT_MAPPING_PATH.name} and re-run.")
        if failed:
            st.error(f"{failed} unit(s) failed — see the reason in the Results table above.")
