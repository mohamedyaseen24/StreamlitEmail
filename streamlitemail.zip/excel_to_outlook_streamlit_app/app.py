"""
app.py — Streamlit front-end for the Excel-to-Outlook pipeline.

Flow: upload workbook -> click Start -> detect units -> split (copy +
delete rows, preserving original formatting) -> resolve recipients from
recipients.xlsx (no dummy fallback: unmatched units are skipped) ->
create a real, editable Outlook Classic draft per matched unit.

Run with:  streamlit run app.py
Requires:  Windows + desktop Outlook Classic installed and signed in,
           for the draft-creation step to succeed.
"""

import shutil

import pandas as pd
import streamlit as st

from modules import config
from modules.excel_loader import save_uploaded_file, open_workbook
from modules.unit_finder import collect_all_units
from modules.splitter import build_unit_workbook
from modules.recipients import load_recipient_mapping, resolve_recipient
from modules.summary_capture import find_summary_sheet, sheet_has_data, sheet_to_html_table
from modules.outlook_draft import create_outlook_draft, OutlookUnavailableError

st.set_page_config(page_title="Excel → Outlook Draft Generator", layout="wide")

st.markdown(
    f"""
    <style>
    .stButton>button {{
        background-color: {config.ACCENT_COLOR};
        color: #0E1117;
        font-weight: 600;
        border-radius: 8px;
        border: none;
        padding: 0.6em 1.4em;
    }}
    .stButton>button:hover {{
        background-color: {config.ACCENT_COLOR_DARK};
        color: white;
    }}
    div[data-testid="stMetric"] {{
        background-color: {config.CARD_BG};
        border-radius: 10px;
        padding: 12px;
    }}
    </style>
    """,
    unsafe_allow_html=True,
)

st.title("📊 Excel → Outlook Draft Generator")
st.caption("Upload a workbook, click Start — everything else happens automatically.")

uploaded_file = st.file_uploader("Master Excel workbook (.xlsx)", type=["xlsx"])

start_disabled = uploaded_file is None
if st.button("🚀 Start Process", type="primary", disabled=start_disabled):

    # --- 0. Fresh output folder every run ---
    if config.OUTPUT_DIR.exists():
        shutil.rmtree(config.OUTPUT_DIR)
    config.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # --- 1. Save upload, load workbook ---
    with st.spinner("Reading workbook..."):
        saved_path = save_uploaded_file(uploaded_file, config.UPLOAD_DIR)
        wb = open_workbook(saved_path)

    # --- 2. Detect all units across all sheets ---
    units = collect_all_units(wb, config.UNIT_COLUMN_ALIASES)
    if not units:
        st.error(
            f"No unit column found matching any of {config.UNIT_COLUMN_ALIASES} on any sheet. "
            "Check modules/config.py's UNIT_COLUMN_ALIASES if your file uses a different header."
        )
        st.stop()

    st.success(f"✅ {len(units)} unit(s) detected: {', '.join(units)}")

    # --- 3. Load recipient mapping (required — no dummy fallback) ---
    try:
        mapping = load_recipient_mapping(config.RECIPIENT_MAPPING_PATH)
    except (FileNotFoundError, ValueError) as e:
        st.error(f"❌ {e}")
        st.stop()

    # --- 4. Split, then draft, per unit ---
    progress = st.progress(0.0, text="Processing units...")
    results = []

    for i, unit_value in enumerate(units):
        row = {"Unit": unit_value, "Rows kept": "-", "Recipient": "-", "Status": "-"}

        split_result = build_unit_workbook(saved_path, unit_value, config.UNIT_COLUMN_ALIASES, config.OUTPUT_DIR)
        total_rows = sum(split_result["rows_kept"].values())
        row["Rows kept"] = total_rows

        recipient = resolve_recipient(unit_value, mapping)
        if recipient is None:
            row["Status"] = "⚠️ Skipped — no recipient mapping found"
            results.append(row)
            progress.progress((i + 1) / len(units), text=f"Processed {unit_value}")
            continue

        row["Recipient"] = recipient["to"]

        # Build the summary table (if this unit actually has summary rows)
        from openpyxl import load_workbook as _load_workbook
        unit_wb = _load_workbook(split_result["path"], data_only=False)
        summary_ws = find_summary_sheet(unit_wb, config.SUMMARY_SHEET_PATTERN)
        summary_html = ""
        if summary_ws is not None and sheet_has_data(summary_ws):
            summary_html = f"<p><b>{summary_ws.title}</b></p>" + sheet_to_html_table(summary_ws)

        html_body = (
            f"<html><body><p>Hi,</p><p>Please find attached the finance document for "
            f"<b>{unit_value}</b>.</p>{summary_html}<p>Regards,</p></body></html>"
        )
        subject = config.SUBJECT_TEMPLATE.format(unit=unit_value)

        try:
            create_outlook_draft(subject, recipient, html_body, split_result["path"])
            row["Status"] = "✅ Draft created"
        except OutlookUnavailableError as e:
            row["Status"] = f"❌ Failed — {e}"

        results.append(row)
        progress.progress((i + 1) / len(units), text=f"Processed {unit_value}")

    progress.empty()

    # --- 5. Final summary ---
    results_df = pd.DataFrame(results)
    st.subheader("Results")
    st.dataframe(results_df, use_container_width=True, hide_index=True)

    created = sum(1 for r in results if r["Status"] == "✅ Draft created")
    skipped = sum(1 for r in results if "Skipped" in r["Status"])
    failed = sum(1 for r in results if "Failed" in r["Status"])

    col1, col2, col3 = st.columns(3)
    col1.metric("Drafts created", created)
    col2.metric("Skipped (no mapping)", skipped)
    col3.metric("Failed", failed)

    if created:
        st.success(f"🎉 {created} of {len(units)} draft(s) created in Outlook. Review and send from your Drafts folder.")
    if skipped:
        st.warning(f"{skipped} unit(s) skipped — add them to {config.RECIPIENT_MAPPING_PATH.name} and re-run.")
    if failed:
        st.error(f"{failed} unit(s) failed — see the reason in the Results table above.")
