"""
unit_finder.py — one job: find the unit column on a sheet (checking every
alias in config.UNIT_COLUMN_ALIASES, case-insensitively) and, across
every sheet in the workbook, build the complete deduplicated unit list.
"""


def find_unit_column(ws, aliases):
    """Scans row 1 for a header matching one of the aliases. Returns the
    1-based column index, or None if this sheet has no unit column."""
    alias_set = {a.strip().lower() for a in aliases}
    for cell in ws[1]:
        if cell.value is not None and str(cell.value).strip().lower() in alias_set:
            return cell.column
    return None


def collect_all_units(wb, aliases):
    """Scans every sheet in the workbook and returns the full,
    deduplicated, sorted list of unit values found anywhere."""
    units = set()
    for ws in wb.worksheets:
        col = find_unit_column(ws, aliases)
        if col is None:
            continue
        for row in ws.iter_rows(min_row=2, min_col=col, max_col=col):
            value = row[0].value
            if value is not None and str(value).strip():
                units.add(str(value).strip())
    return sorted(units, key=str)
