"""
splitter.py — one job: for a given unit, produce a copy of the ORIGINAL
workbook with every row that doesn't belong to that unit deleted.

This is deliberately NOT a rebuild-from-extracted-data approach (like
pandas.ExcelWriter would do) — that loses anything beyond raw cell
values: formulas, colors, borders, merged cells, column widths. Instead,
every unit's file starts as a fresh, full copy of the original file on
disk, then has the non-matching rows removed in place. Whatever the
original file looked like, the split file looks the same, minus rows.
"""

import re
from pathlib import Path

from openpyxl import load_workbook

from .unit_finder import find_unit_column


def safe_filename(value: str) -> str:
    text = str(value).strip()
    text = re.sub(r'[\\/*?:"<>|]', "_", text)
    text = re.sub(r"\s+", "_", text)
    return text or "blank"


def build_unit_workbook(original_path: Path, unit_value: str, aliases: list, output_dir: Path) -> dict:
    """Loads a FRESH copy of the original file (fresh per unit, so no
    state leaks between units), deletes every row not belonging to
    unit_value on every sheet that has a unit column, and saves it as
    <unit>.xlsx in output_dir.

    Returns a small report dict: {"path": Path, "rows_kept": {sheet_name: int}}
    """
    wb = load_workbook(original_path, data_only=False)
    rows_kept = {}

    for ws in wb.worksheets:
        col = find_unit_column(ws, aliases)
        if col is None:
            continue  # no unit column on this sheet -> leave it fully intact

        kept = 0
        # Walk bottom-to-top so deleting a row never shifts the index of
        # rows we haven't checked yet.
        for row_idx in range(ws.max_row, 1, -1):
            cell_value = ws.cell(row=row_idx, column=col).value
            matches = cell_value is not None and str(cell_value).strip() == str(unit_value).strip()
            if matches:
                kept += 1
            else:
                ws.delete_rows(row_idx, 1)

        rows_kept[ws.title] = kept

    out_path = output_dir / f"{safe_filename(unit_value)}.xlsx"
    wb.save(out_path)
    return {"path": out_path, "rows_kept": rows_kept}
